function redirectToProp() {
    window.open('formRegisterProp.html', '_blank')
}
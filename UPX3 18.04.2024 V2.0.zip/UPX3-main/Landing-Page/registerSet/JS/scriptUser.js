function redirectToUser() {
    window.open('formRegisterUser.html', '_blank')
}
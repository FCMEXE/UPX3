function redirectTolandingPage() {
  window.location.href = "/Landing-Page/index.html";
}

function redirectToWhatsApp() {
  window.location.href =
    "https://api.whatsapp.com/send?phone=+5515992832003&text=ol%C3%A1%2C+necessito+de+suporte.%0AQuadraConecta%21%21%21%E2%9A%BD%EF%B8%8F";
}

function redirectToTelefone() {
  window.location.href = "tel:+15992832003";
}

function redirectToEmail() {
  window.location.href = "mailto:lucasjesuss2004@gmail.com";
}
